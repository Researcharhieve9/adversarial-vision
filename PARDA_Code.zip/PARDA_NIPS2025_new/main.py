import torch
import argparse
import os
import random
import numpy as np
from torch.utils.data import DataLoader, TensorDataset
import torch.nn as nn
import torch.optim as optim
from config import Config
from net import FeatureExtractor, Classifier, FullModel
from utils import get_source_loaders, get_target_loader, pgd_attack, get_pseudo_labeled_target, save_pgd_attacks
from train import warmup_step, mcd_step
from dataset import load_split_source_data, load_split_target_data
from tqdm import tqdm

def compute_tcr(G, H1, H2, tgt_loader, device):
    G.eval(); H1.eval(); H2.eval()
    total, agree = 0, 0
    with torch.no_grad():
        for tgt_batch in tgt_loader:
            x, _ = tgt_batch
            x = x.to(device)
            feat = G(x)
            pred1 = H1(feat).argmax(dim=1)
            pred2 = H2(feat).argmax(dim=1)
            agree += (pred1 == pred2).sum().item()
            total += x.size(0)
    return agree / total if total > 0 else 0


def main(args):
    random.seed(args.seed)
    np.random.seed(args.seed)
    torch.manual_seed(args.seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(args.seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False

    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    root = f"./{args.dataset.lower()}"
    clean_source_dir = os.path.join(root, args.source)
    adv_source_dir = os.path.join(root, args.source + "_adv")
    target_dir = os.path.join(root, args.target)

    E_warm = 5
    pseudo_update_interval = 10
    batch_size = 64 if args.dataset.upper() == 'DIGIT' else args.batch_size
    lr = args.lr

    print("[INFO] Initializing models and optimizers...")

    num_classes = Config.get_num_classes(args.dataset)

    G = FeatureExtractor(pretrained=True, dataset=args.dataset)
    if torch.cuda.device_count() > 1 and args.multigpu:
        G = nn.DataParallel(G)
    G = G.to(device)

    H1 = Classifier(num_classes)
    if torch.cuda.device_count() > 1 and args.multigpu:
        H1 = nn.DataParallel(H1)
    H1 = H1.to(device)

    H2 = Classifier(num_classes)
    if torch.cuda.device_count() > 1 and args.multigpu:
        H2 = nn.DataParallel(H2)
    H2 = H2.to(device)

    weight_decay_value = 0.0 if args.dataset.upper() == 'DIGIT' else 5e-5
    optimizer_G = optim.Adam(
        G.parameters(), lr=lr * 0.1, weight_decay=weight_decay_value, betas=(0.9, 0.999)
    )
    optimizer_H1 = optim.Adam(
        H1.parameters(), lr=lr, weight_decay=weight_decay_value, betas=(0.9, 0.999)
    )
    optimizer_H2 = optim.Adam(
        H2.parameters(), lr=lr, weight_decay=weight_decay_value, betas=(0.9, 0.999)
    )

    criterion = nn.CrossEntropyLoss()
    print("[INFO] Model and optimizer initialization done.")

    full_model = FullModel(G, H1).to(device)

    print("[INFO] Loading source and target data loaders...")
    src_clean_loader, src_val_loader = load_split_source_data(
        clean_source_dir,
        batch_size=batch_size,
        val_split=args.val_split,
        dataset_type=args.dataset,
        seed=args.seed
    )

    tgt_loader, tgt_test_loader = load_split_target_data(
        target_dir,
        batch_size=batch_size,
        val_split=0.2,
        dataset_type=args.dataset,
        seed=args.seed
    )

    print("[INFO] Data loaders ready.")

    def create_adv_loader(model, clean_loader, device, eps=8/255, alpha=2/255, iters=20, batch_size=None):
        adv_images_list = []
        adv_labels_list = []
        model.eval()
        for images, labels in tqdm(clean_loader, desc="Creating adv source", leave=True):
            images, labels = images.to(device), labels.to(device)
            adv_images = pgd_attack(model, images, labels, eps=eps, alpha=alpha, iters=iters)
            adv_images_list.append(adv_images.detach().cpu())
            adv_labels_list.append(labels.detach().cpu())
        if len(adv_images_list) == 0:
            return DataLoader([], batch_size=batch_size or clean_loader.batch_size, shuffle=False)
        adv_imgs = torch.cat(adv_images_list, dim=0)
        adv_lbls = torch.cat(adv_labels_list, dim=0)
        ds = TensorDataset(adv_imgs, adv_lbls)
        return DataLoader(ds, batch_size=batch_size or clean_loader.batch_size, shuffle=False)

    src_adv_loader = create_adv_loader(full_model, src_clean_loader, device, batch_size=batch_size)

    # === 1. Warm-up Phase ===
    print("[INFO] Starting warm-up phase...")
    for epoch in range(E_warm):
      iter_total = min(len(src_clean_loader), len(src_adv_loader)) if len(src_adv_loader) > 0 else len(src_clean_loader)
      for batch_cln, batch_adv in tqdm(zip(src_clean_loader, src_adv_loader),
                                        total=iter_total,
                                        desc=f"Warmup Epoch {epoch+1}/{E_warm}",
                                        leave=True):
          warmup_step(G, H1, H2, batch_cln, batch_adv, optimizer_G, optimizer_H1, optimizer_H2, criterion, device)

    # === 2. Explicit Alignment ===
    print("[INFO] Starting explicit alignment with TCR-based stopping...")
    max_E_align = 10
    stagnate_count = 0
    max_stagnate = 3
    prev_tcr = 0.0

    epoch = 0
    while epoch < max_E_align and stagnate_count < max_stagnate:
      # classifier discrepancy maximization on target
      for tgt_batch in tqdm(tgt_loader, desc=f"MCD max epoch {epoch+1}", leave=True):
          mcd_step(G, H1, H2, None, [optimizer_H1, optimizer_H2], tgt_batch, device, step='max')
      # minimize discrepancy by updating G
      for tgt_batch in tqdm(tgt_loader, desc=f"MCD min epoch {epoch+1}", leave=True):
          mcd_step(G, H1, H2, optimizer_G, None, tgt_batch, device, step='min')
      curr_tcr = compute_tcr(G, H1, H2, tgt_loader, device)
      print(f"[MCD] Epoch {epoch + 1}, TCR: {curr_tcr:.4f}")
      stagnate_count = stagnate_count + 1 if abs(curr_tcr - prev_tcr) < 1e-3 else 0
      prev_tcr = curr_tcr
      epoch += 1

    # === 3. Pseudo-label generation ===
    print("[INFO] Generating pseudo-labeled target subsets...")
    Dt0, Dt_adv, Dt_curr = get_pseudo_labeled_target(G, H1, H2, tgt_loader, device)

    Dt_adv_cln = [x for x, _ in Dt_adv]
    Dt_adv_labels = [y for _, y in Dt_adv]
    Dt_adv_adv = []
    for x, y in Dt_adv:
        Dt_adv_adv.append(pgd_attack(full_model, x.to(device).unsqueeze(0), y.to(device).unsqueeze(0)).detach().cpu().squeeze(0))

    Dt_curr_sorted = Dt_curr[:]
    curriculum_ptr = 0
    curriculum_step = max(1, len(Dt_curr_sorted) // 5) if len(Dt_curr_sorted) > 0 else 1

    print("[INFO] Starting implicit alignment phase...")
    max_epochs_implicit = 30
    epoch = 0

    while compute_tcr(G, H1, H2, tgt_loader, device) < 0.99 and epoch < max_epochs_implicit:
        if curriculum_ptr >= len(Dt_curr_sorted):
            curriculum_ptr = 0

        Dt_curr_buffer = Dt_curr_sorted[curriculum_ptr: curriculum_ptr + curriculum_step]
        if len(Dt_curr_buffer) == 0:
            break

        Dt_curr_cln = [x for x, _ in Dt_curr_buffer]
        Dt_curr_labels = [y for _, y in Dt_curr_buffer]
        Dt_curr_adv = []
        for x, y in Dt_curr_buffer:
            adv = pgd_attack(full_model, x.to(device).unsqueeze(0), y.to(device).unsqueeze(0)).detach().cpu().squeeze(0)
            Dt_curr_adv.append(adv)

        tgt_combined_x = Dt_adv_cln + Dt_adv_adv + Dt_curr_cln + Dt_curr_adv
        tgt_combined_y = Dt_adv_labels + Dt_adv_labels + Dt_curr_labels + Dt_curr_labels

        if len(tgt_combined_x) == 0:
            break
        x_tensor = torch.stack(tgt_combined_x, dim=0)
        y_tensor = torch.stack(tgt_combined_y, dim=0)
        tgt_combined_dataset = TensorDataset(x_tensor, y_tensor)
        tgt_loader_combined = DataLoader(tgt_combined_dataset, batch_size=batch_size, shuffle=True)

        # === Train on combined target set ===
        for batch in tqdm(tgt_loader_combined, desc=f"Implicit Epoch {epoch+1}/{max_epochs_implicit}", leave=True):
            warmup_step(G, H1, H2, batch, batch, optimizer_G, optimizer_H1, optimizer_H2, criterion, device)

        curriculum_ptr += curriculum_step
        epoch += 1

        # === Recompute pseudo-labels every n epochs ===
        if (epoch) % pseudo_update_interval == 0:
            Dt0, Dt_adv, Dt_curr = get_pseudo_labeled_target(G, H1, H2, tgt_loader, device)
            Dt_adv_cln = [x for x, _ in Dt_adv]
            Dt_adv_labels = [y for _, y in Dt_adv]
            Dt_adv_adv = []
            for x, y in Dt_adv:
                Dt_adv_adv.append(pgd_attack(full_model, x.to(device).unsqueeze(0), y.to(device).unsqueeze(0)).detach().cpu().squeeze(0))
            Dt_curr_sorted = Dt_curr[:]
            curriculum_ptr = 0
            curriculum_step = max(1, len(Dt_curr_sorted) // 5) if len(Dt_curr_sorted) > 0 else 1

    # === Save model ===
    model_name = f"{args.dataset.lower()}_{args.source}_to_{args.target}.pth"
    torch.save({
        'G': G.state_dict(),
        'H1': H1.state_dict(),
        'H2': H2.state_dict()
    }, model_name)
    print(f"[INFO] Training complete. Model saved to {model_name}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--dataset", type=str, required=True, help="Dataset name (e.g., OFFICEHOME, PACS, DIGIT, VISDA)")
    parser.add_argument('--seed', type=int, default=42, help='Random seed for reproducibility')
    parser.add_argument("--source", type=str, required=True, help="Source domain")
    parser.add_argument("--target", type=str, required=True, help="Target domain")
    parser.add_argument('--batch_size', type=int, default=16)
    parser.add_argument('--val_split', type=float, default=0.1)
    parser.add_argument('--lr', type=float, default=1e-4)
    parser.add_argument('--multigpu', action='store_true', help='Enable multi-GPU training with DataParallel')

    args = parser.parse_args()
    main(args)
