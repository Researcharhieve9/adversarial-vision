import os
import argparse
import torch
from utils import get_target_loader, get_source_loaders, pgd_accuracy, plot_combined_tsne
from net import FeatureExtractor, Classifier
from torchvision import datasets
from torch.utils.data import DataLoader, random_split


parser = argparse.ArgumentParser()
parser.add_argument('--dataset', type=str, required=True)
parser.add_argument('--source', type=str, required=True)
parser.add_argument('--target', type=str, required=True)
parser.add_argument('--attack', type=str, default='none', choices=['none', 'pgd'])
parser.add_argument('--eps', type=float, default=2/255)
parser.add_argument('--atk_lr', type=float, default=1/255)
parser.add_argument('--atk_iter', type=int, default=20)
parser.add_argument('--batch_size', type=int, default=16)
parser.add_argument('--ckpt_path', type=str, default=None, help="Path to custom checkpoint file")  
parser.add_argument('--tsne', action='store_true')

args = parser.parse_args()
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

if args.ckpt_path:
    ckpt_name = args.ckpt_path
else:
    ckpt_name = f"{args.dataset.lower()}_{args.source}_to_{args.target}.pth"

if not os.path.exists(ckpt_name):
    print(f"[ERROR] Checkpoint {ckpt_name} not found.")
    exit()


# Load model
G = FeatureExtractor(pretrained=False, dataset=args.dataset).to(device)
H1 = Classifier(G.output_dim).to(device)
checkpoint = torch.load(ckpt_name)
G.load_state_dict(checkpoint['G'])
H1.load_state_dict(checkpoint['H1'])
G.eval(); H1.eval()

# Load data



target_dir = os.path.join(f"./{args.dataset.lower()}", args.target)
target_loader = get_target_loader(target_dir, batch_size=args.batch_size, dataset=args.dataset)

source_dir = os.path.join(f"./{args.dataset.lower()}", args.source)
source_loader = get_source_loader(target_dir, batch_size=args.batch_size, dataset=args.dataset)




# Evaluate on clean
clean_accs = []
adv_accs = []

for run in range(3):
    correct = 0; total = 0
    with torch.no_grad():
        for x, y in target_loader:
            x, y = x.to(device), y.to(device)
            preds = H1(G(x)).argmax(1)
            correct += (preds == y).sum().item()
            total += y.size(0)
    acc = 100 * correct / total
    clean_accs.append(acc)
    print(f"[RUN {run+1}] Clean Acc: {acc:.2f}%")

    # Adversarial accuracy
    if args.attack == 'pgd':
        adv_acc = pgd_accuracy(lambda x: H1(G(x)), target_loader, args.eps, args.atk_lr, args.atk_iter, device)
        adv_accs.append(100 * adv_acc)
        print(f"[RUN {run+1}] Adv Acc: {100 * adv_acc:.2f}%")

print(f"Clean Accuracy: {sum(clean_accs)/3:.2f} ± {torch.std(torch.tensor(clean_accs)):.2f}")
if args.attack == 'pgd':
    print(f"Adv Accuracy: {sum(adv_accs)/3:.2f} ± {torch.std(torch.tensor(adv_accs)):.2f}")

# Optional TSNE
if args.tsne:
    plot_combined_tsne(G, H1, source_loader, target_loader, device,
        save_path=f"tsne_{args.dataset}_{args.source}_to_{args.target}.png")

