from resnet import resnet50  # your custom ResNet-50
import torch.nn as nn
import torch.nn.functional as F
import torch.nn.init as init


class FeatureExtractor(nn.Module):
    def __init__(self, pretrained=True, dataset='OFFICEHOME'):
        super().__init__()
        if dataset.upper() == 'DIGIT':
            self.backbone = nn.Sequential(
                nn.Conv2d(3, 64, kernel_size=5, stride=1, padding=2),
                nn.BatchNorm2d(64),
                nn.ReLU(),
                nn.MaxPool2d(2),

                nn.Conv2d(64, 128, kernel_size=5, stride=1, padding=2),
                nn.BatchNorm2d(128),
                nn.ReLU(),
                nn.MaxPool2d(2),

                nn.Conv2d(128, 128, kernel_size=3, stride=1, padding=1),
                nn.BatchNorm2d(128),
                nn.ReLU(),
                nn.AdaptiveAvgPool2d((1, 1))
            )
            self.output_dim = 128
        else:
            resnet = resnet50(pretrained=pretrained)
            self.backbone = resnet
            self.output_dim = 2048

    def forward(self, x):
        if isinstance(self.backbone, nn.Sequential):
            x = self.backbone(x)
        else:
            _, _, _, _, x = self.backbone(x)  # use final res5 from custom resnet
            x = F.adaptive_avg_pool2d(x, (1, 1))
        return x.view(x.size(0), -1)




class Classifier(nn.Module):
    def __init__(self, num_classes=65, input_dim=2048):
        super().__init__()
        self.fc = nn.Linear(input_dim, num_classes)
        
        # Xavier initialization for weights
        init.xavier_uniform_(self.fc.weight)
        
        # Zero initialization for biases
        if self.fc.bias is not None:
            init.constant_(self.fc.bias, 0)

    def forward(self, x):
        return self.fc(x)



class FullModel(nn.Module):
    def __init__(self, feature_extractor, classifier):
        super().__init__()
        self.F = feature_extractor
        self.H = classifier

    def forward(self, x):
        feat = self.F(x)
        out = self.H(feat)
        return out

