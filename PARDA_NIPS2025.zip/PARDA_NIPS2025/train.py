import torch
import torch.nn.functional as F


def warmup_step(G, H1, H2, batch_cln, batch_adv,
                optimizer_G, optimizer_H1, optimizer_H2,
                criterion, device):
    """
    Warm-up training step on source clean and adversarial batches.
    """
    G.train()
    H1.train()
    H2.train()

    optimizer_G.zero_grad()
    optimizer_H1.zero_grad()
    optimizer_H2.zero_grad()

    inputs_clean, labels_clean = batch_cln
    inputs_adv, labels_adv = batch_adv

    inputs_clean, labels_clean = inputs_clean.to(device), labels_clean.to(device)
    inputs_adv, labels_adv = inputs_adv.to(device), labels_adv.to(device)

    feats_clean = G(inputs_clean)
    logits1_clean = H1(feats_clean)
    logits2_clean = H2(feats_clean)

    feats_adv = G(inputs_adv)
    logits1_adv = H1(feats_adv)
    logits2_adv = H2(feats_adv)

    loss_clean_1 = criterion(logits1_clean, labels_clean)
    loss_clean_2 = criterion(logits2_clean, labels_clean)
    loss_adv_1 = criterion(logits1_adv, labels_adv)
    loss_adv_2 = criterion(logits2_adv, labels_adv)

    loss = (loss_clean_1 + loss_clean_2 + loss_adv_1 + loss_adv_2) / 4.0
    loss.backward()

    optimizer_G.step()
    optimizer_H1.step()
    optimizer_H2.step()

    return loss.item()


def mcd_step(G, H1, H2, optimizer_G, optimizer_H, tgt_batch, device, step='max'):
    """
    Performs one step of MCD:
    - If step == 'max': maximize discrepancy between H1 and H2 (update classifiers)
    - If step == 'min': minimize discrepancy by updating G (feature extractor)
    """
    G.train()
    H1.train()
    H2.train()

    inputs, _ = tgt_batch
    inputs = inputs.to(device)

    feats = G(inputs)
    logits1 = H1(feats)
    logits2 = H2(feats)

    disc = torch.mean(torch.abs(F.softmax(logits1, dim=1) - F.softmax(logits2, dim=1)))

    if step == 'max':
        optimizer_H1, optimizer_H2 = optimizer_H
        optimizer_H1.zero_grad()
        optimizer_H2.zero_grad()
        loss = -disc
        loss.backward()
        optimizer_H1.step()
        optimizer_H2.step()

    elif step == 'min':
        optimizer_G.zero_grad()
        loss = disc
        loss.backward()
        optimizer_G.step()

    return loss.item()
