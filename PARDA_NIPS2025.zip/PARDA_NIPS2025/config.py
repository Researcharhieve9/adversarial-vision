import os
import torch

class Config:
    batch_size = 16
    lr = 1e-4
    num_epochs_warmup = 10
    pseudo_update_interval = 10
    device = 'cuda' if torch.cuda.is_available() else 'cpu'
    checkpoint_path = './checkpoints/'

    dataset_classes = {
        'OFFICEHOME': 65,
        'PACS': 7,
        'DIGIT': 10,
        'VISDA': 12
    }

    @staticmethod
    def get_num_classes(dataset_name):
        return Config.dataset_classes.get(dataset_name.upper(), 0)

    os.makedirs(checkpoint_path, exist_ok=True)

