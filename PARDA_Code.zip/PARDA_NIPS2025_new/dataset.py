import os
from torchvision import datasets, transforms
from torch.utils.data import DataLoader, Subset
import numpy as np

def get_transform(dataset_type):
    if dataset_type.upper() == 'DIGIT':
        return transforms.Compose([
            transforms.Resize((32, 32)),
            transforms.Grayscale(num_output_channels=3),
            transforms.ToTensor(),
            transforms.Normalize(mean=[0.5]*3, std=[0.5]*3)
        ])
    else:
        return transforms.Compose([
            transforms.RandomResizedCrop(224, scale=(0.8, 1.0), ratio=(3./4., 4./3.)),
            transforms.RandomHorizontalFlip(),
            transforms.ColorJitter(brightness=0.4, contrast=0.4, saturation=0.4, hue=0.1),
            transforms.RandomGrayscale(p=0.1),
            transforms.ToTensor(),
            transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
        ])

def split_dataset(dataset, val_fraction=0.1, seed=42):
    num_samples = len(dataset)
    indices = np.arange(num_samples)
    np.random.seed(seed)
    np.random.shuffle(indices)
    split = int(np.floor(val_fraction * num_samples))
    val_indices, train_indices = indices[:split], indices[split:]
    return Subset(dataset, train_indices), Subset(dataset, val_indices)

def load_split_source_data(data_dir, batch_size=32, num_workers=4, val_split=0.1, dataset_type='OFFICEHOME', seed=42):
    transform = get_transform(dataset_type)
    full_dataset = datasets.ImageFolder(data_dir, transform=transform)
    train_dataset, val_dataset = split_dataset(full_dataset, val_fraction=val_split, seed=seed)

    train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True, num_workers=num_workers, drop_last=True)
    val_loader = DataLoader(val_dataset, batch_size=batch_size, shuffle=False, num_workers=num_workers)

    return train_loader, val_loader

def load_split_target_data(data_dir, batch_size=32, val_split=0.2, dataset_type='OFFICEHOME', seed=42):
    transform = get_transform(dataset_type)
    full_dataset = datasets.ImageFolder(data_dir, transform=transform)
    train_dataset, val_dataset = split_dataset(full_dataset, val_fraction=val_split, seed=seed)

    train_target_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True, num_workers=4)
    test_loader = DataLoader(val_dataset, batch_size=batch_size, shuffle=False, num_workers=4)

    return train_target_loader, test_loader


