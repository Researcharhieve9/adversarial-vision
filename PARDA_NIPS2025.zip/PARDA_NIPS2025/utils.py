import os
from torchvision import datasets, transforms
from torch.utils.data import DataLoader
import torch.nn.functional as F
import torch
import torch.nn as nn
from tqdm import tqdm
from torchvision.utils import save_image
from sklearn.manifold import TSNE
import matplotlib.pyplot as plt
import numpy as np
from torch.utils.data import TensorDataset
import matplotlib.pyplot as plt
import seaborn as sns



def get_source_loaders(clean_source_dir, adv_source_dir, batch_size=32, num_workers=4, dataset="OFFICEHOME"):
    if dataset.upper() == 'DIGIT':
        transform = transforms.Compose([
            transforms.Resize((32, 32)),
            transforms.Grayscale(num_output_channels=3),
            transforms.ToTensor(),
            transforms.Normalize(mean=[0.5]*3, std=[0.5]*3)
        ])
    else:
        transform = transforms.Compose([
            transforms.RandomResizedCrop(224, scale=(0.8, 1.0), ratio=(3./4., 4./3.)),
            transforms.RandomHorizontalFlip(),
            transforms.ColorJitter(brightness=0.4, contrast=0.4, saturation=0.4, hue=0.1),
            transforms.RandomGrayscale(p=0.1),
            transforms.ToTensor(),
            transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
        ])

    clean_ds = datasets.ImageFolder(clean_source_dir, transform=transform)
    adv_ds = datasets.ImageFolder(adv_source_dir, transform=transform)

    clean_loader = DataLoader(clean_ds, batch_size=batch_size, shuffle=True, num_workers=num_workers, drop_last=True)
    adv_loader = DataLoader(adv_ds, batch_size=batch_size, shuffle=True, num_workers=num_workers, drop_last=True)

    return clean_loader, adv_loader

def get_target_loader(target_dir, batch_size=32, num_workers=4, shuffle=True, dataset="OFFICEHOME"):
    if dataset.upper() == 'DIGIT':
        transform = transforms.Compose([
            transforms.Resize((32, 32)),
            transforms.Grayscale(num_output_channels=3),
            transforms.ToTensor(),
            transforms.Normalize(mean=[0.5]*3, std=[0.5]*3)
        ])
    else:
        transform = transforms.Compose([
            transforms.RandomResizedCrop(224, scale=(0.8, 1.0), ratio=(3./4., 4./3.)),
            transforms.RandomHorizontalFlip(),
            transforms.ColorJitter(brightness=0.4, contrast=0.4, saturation=0.4, hue=0.1),
            transforms.RandomGrayscale(p=0.1),
            transforms.ToTensor(),
            transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
        ])

    target_ds = datasets.ImageFolder(target_dir, transform=transform)
    target_loader = DataLoader(target_ds, batch_size=batch_size, shuffle=shuffle, num_workers=num_workers)
    return target_loader
    
    
def pgd_attack(model, images, labels, eps=2/255, alpha=1/255, iters=20):
    images = images.clone().detach()
    labels = labels.clone().detach()
    ori_images = images.clone().detach()

    delta = torch.zeros_like(images).uniform_(-eps, eps)
    delta = delta.to(images.device)
    delta.requires_grad = True

    for _ in range(iters):
        outputs = model(images + delta)
        loss = F.cross_entropy(outputs, labels)
        loss.backward()
        grad = delta.grad.detach()
        delta.data = (delta + alpha * grad.sign()).clamp(-eps, eps)
        delta.data = (ori_images + delta).clamp(0, 1) - ori_images
        delta.grad.zero_()

    return (ori_images + delta).detach()

def get_classifier_agreement(logits1, logits2):
    preds1 = torch.argmax(logits1, dim=1)
    preds2 = torch.argmax(logits2, dim=1)
    agreement_mask = (preds1 == preds2)
    return agreement_mask, preds1  # agreement mask and pseudo labels from H1



def get_pseudo_labeled_target(G, H1, H2, target_loader, device):
    print('pseudo')
    G.eval()
    H1.eval()
    H2.eval()

    pseudo_inputs = []
    pseudo_labels = []

    with torch.no_grad():
        for inputs, _ in target_loader:
            inputs = inputs.to(device)
            feats = G(inputs)
            logits1 = H1(feats)
            logits2 = H2(feats)

            agree_mask, pseudo_batch = get_classifier_agreement(logits1, logits2)
            agreed_inputs = inputs[agree_mask]
            agreed_labels = pseudo_batch[agree_mask]

            if agreed_inputs.size(0) > 0:
                pseudo_inputs.append(agreed_inputs.cpu())
                pseudo_labels.append(agreed_labels.cpu())

    if len(pseudo_inputs) == 0:
        return None, None, None

    pseudo_inputs = torch.cat(pseudo_inputs, dim=0)
    pseudo_labels = torch.cat(pseudo_labels, dim=0)
    Dt0 = list(zip(pseudo_inputs, pseudo_labels))

    # --- Step 9: Adversarial agreement (Dt_adv) ---
    
    adv_inputs = pgd_attack(G, H1, pseudo_inputs.to(device), pseudo_labels.to(device), device)
    adv_feats = G(adv_inputs)
    logits1_adv = H1(adv_feats)
    logits2_adv = H2(adv_feats)

    adv_agree_mask, _ = get_classifier_agreement(logits1_adv, logits2_adv)
    Dt_adv = list(zip(pseudo_inputs[adv_agree_mask], pseudo_labels[adv_agree_mask]))

    # --- Step 10: Dcurr = Dt0 - Dt_adv (by id), sorted by max confidence ---
    mask_dt_adv = torch.zeros(len(pseudo_inputs), dtype=torch.bool)
    mask_dt_adv[adv_agree_mask] = True
    dt_curr_inputs = pseudo_inputs[~mask_dt_adv]
    dt_curr_labels = pseudo_labels[~mask_dt_adv]

    with torch.no_grad():
        feats = G(dt_curr_inputs.to(device))
        logits = H1(feats)  # could use avg(H1+H2) too
        probs = torch.softmax(logits, dim=1)
        conf_scores, _ = probs.max(dim=1)
        sorted_indices = torch.argsort(conf_scores, descending=True)

    Dt_curr = [(dt_curr_inputs[i], dt_curr_labels[i]) for i in sorted_indices]

    return Dt0, Dt_adv, Dt_curr


def save_pgd_attacks(model, clean_data_dir, save_dir, batch_size=32, eps=2/255, alpha=1/255, iters=5):
    """
    Generate PGD images from clean data and save them into class-wise directories.
    Arguments:
        model: Trained model (F + H)
        clean_data_dir: Path to clean dataset (e.g., officehome/Art)
        save_dir: Where to save adversarial examples (e.g., officehome_adv/Art)
    """
    os.makedirs(save_dir, exist_ok=True)
    model.eval()
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model.to(device)

    transform = transforms.Compose([
        transforms.Resize((224, 224)),
        transforms.ToTensor(),
        transforms.Normalize([0.5]*3, [0.5]*3)
    ])

    dataset = datasets.ImageFolder(clean_data_dir, transform=transform)
    loader = DataLoader(dataset, batch_size=batch_size, shuffle=False, num_workers=4)

    class_to_idx = dataset.class_to_idx
    idx_to_class = {v: k for k, v in class_to_idx.items()}

    print(f"Saving PGD adversarial images to {save_dir}...")

    for class_name in class_to_idx:
        os.makedirs(os.path.join(save_dir, class_name), exist_ok=True)

    counter = {cls: 0 for cls in class_to_idx}

    for images, labels in tqdm(loader):
        images, labels = images.to(device), labels.to(device)
        adv_images = pgd_attack(model, images, labels, eps, alpha, iters)

        for i in range(images.size(0)):
            class_idx = labels[i].item()
            class_name = idx_to_class[class_idx]
            save_path = os.path.join(save_dir, class_name, f"{counter[class_name]:05d}.png")
            save_image(adv_images[i].cpu(), save_path)
            counter[class_name] += 1

    print("PGD adversarial image saving complete.")



def pgd_accuracy(model, loader, eps=2/255, alpha=1/255, iters=20, device='cuda'):
    model.eval()
    correct = 0
    total = 0

    for images, labels in loader:
        images, labels = images.to(device), labels.to(device)
        adv_images = pgd_attack(model, images, labels, eps, alpha, iters)
        with torch.no_grad():
            outputs = model(adv_images)
            preds = outputs.argmax(dim=1)
            correct += (preds == labels).sum().item()
            total += labels.size(0)

    acc = correct / total
    return acc


def plot_combined_tsne(G, H, src_loader, tgt_loader, device, save_path="tsne_combined.png", max_samples=300):
    
    G.eval()
    H.eval()
    all_feats = []
    all_labels = []
    all_domains = []

    def extract_features(loader, domain_tag, use_adv):
        model = nn.Sequential(G, H).to(device)
        count = 0
        with torch.no_grad():
            for x, y in loader:
                x, y = x.to(device), y.to(device)
                if use_adv:
                    x = pgd_attack(model, x, y)
                feat = G(x).cpu().numpy()
                all_feats.append(feat)
                all_labels.extend(y.cpu().numpy())
                all_domains += [domain_tag] * x.size(0)
                count += x.size(0)
                if count >= max_samples:
                    break

    # Source Clean + Adv
    extract_features(src_loader, "Source Clean", use_adv=False)
    extract_features(src_loader, "Source Adv", use_adv=True)

    # Target Clean + Adv
    extract_features(tgt_loader, "Target Clean", use_adv=False)
    extract_features(tgt_loader, "Target Adv", use_adv=True)

    X = np.concatenate(all_feats)[:4*max_samples]
    Y = np.array(all_labels)[:4*max_samples]
    D = np.array(all_domains)[:4*max_samples]

    # t-SNE
    tsne = TSNE(n_components=2, perplexity=30, n_iter=1000, random_state=42)
    X_reduced = tsne.fit_transform(X)

    # Plot
    plt.figure(figsize=(10, 8))
    unique_domains = np.unique(D)
    palette = sns.color_palette("tab10", len(unique_domains))
    for i, d in enumerate(unique_domains):
        idx = D == d
        plt.scatter(X_reduced[idx, 0], X_reduced[idx, 1], c=[palette[i]], label=d, alpha=0.7, s=15, marker='o')

    plt.legend(title="Domain View")
    plt.title("t-SNE: Source/Target - Clean/Adversarial")
    plt.tight_layout()
    plt.savefig(save_path)
    print(f"[INFO] Saved t-SNE plot to {save_path}")
    plt.close()

#def plot_combined_tsne(G, H, src_loader, tgt_loader, device, save_path="tsne_combined.png"):
 #   G.eval()
  #  H.eval()
   # all_feats = []
   # all_labels = []
#  #  all_domains = []

#    def extract_features(loader, domain_tag, use_adv):
 #       model = nn.Sequential(G, H).to(device)
  #      for x, y in loader:
#            x, y = x.to(device), y.to(device)
  #          if use_adv:
   #             x = pgd_attack(model, x, y)
    #        with torch.no_grad():
     #           feat = G(x)
     #           all_feats.append(feat.cpu().numpy())
     #          all_labels.append(y.cpu().numpy())
     #           all_domains += [domain_tag] * x.size(0)

    # Source Clean + Adv
    #extract_features(src_loader, "src_clean", use_adv=False)
    #extract_features(src_loader, "src_adv", use_adv=True)

    # Target Clean + Adv
    #extract_features(tgt_loader, "tgt_clean", use_adv=False)
   # extract_features(tgt_loader, "tgt_adv", use_adv=True)

    #X = np.concatenate(all_feats)
    #Y = np.concatenate(all_labels)
    #D = np.array(all_domains)

    #tsne = TSNE(n_components=2, perplexity=30, n_iter=1000, random_state=42)
    #X_reduced = tsne.fit_transform(X)

    #fig, ax = plt.subplots(figsize=(10, 8))
    #markers = {"src_clean": "o", "src_adv": "x", "tgt_clean": "^", "tgt_adv": "s"}
    #for d in np.unique(D):
     #   idx = D == d
      #  scatter = ax.scatter(X_reduced[idx, 0], X_reduced[idx, 1], c=Y[idx], cmap='tab10', marker=markers[d], label=d, alpha=0.6, s=10)

    #ax.legend(title="Domain")
    #ax.set_title("t-SNE across Source/Target and Clean/Adversarial")
#    plt.tight_layout()
  #  plt.savefig(save_path)
 #   print(f"[INFO] Saved t-SNE plot to {save_path}")
   # plt.close()

